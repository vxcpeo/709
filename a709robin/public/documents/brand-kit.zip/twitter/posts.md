# Tranova — launch drafts

Live identity: **Tranova / @TranovaSite / www.tranova.site**. The X account is public and the site is live at https://www.tranova.site/. Add the verified URL at publication and recheck the character count.

## 01 — Introduction

```text
Meet Tranova. Make timing accountable.

One workspace for vesting, locks, streams and vested distributions. Set the terms, fund the schedule, let recipients inspect and claim.

Robinhood Chain Testnet. Test tokens only.
```

Image: `01-introducing-tranova.jpg` — 1600×900 JPG.

Alt text: A deep-space Tranova card reads “Make timing accountable.” A blue orbital ring mark sits inside concentric constellation circles on the right. Supporting copy names vesting, locks, streams and vested distributions. The footer labels Robinhood Chain Testnet.

## 02 — Release map

```text
Make the timing visible.

Choose an explicit cliff, cadence and end date. Fund the allocation once; recipients claim what has vested. Optional cancellation preserves vested value and refunds only the unvested balance.

Tranova. Testnet only.
```

Image: `02-release-map.jpg` — 1600×900 JPG.

Alt text: A dark Tranova card reads “Make the timing visible.” A stepped blue release map rises across constellation circles, ending at a violet release marker. The header names set terms, fund and claim as the three steps.

## 03 — Vested distributions

```text
Shared timing. Individual claims.

Create up to 100 vested allocations in one Tranova batch. Fund them together; recipients inspect and claim independently as tokens unlock.

Robinhood Chain Testnet. No real-value assets.
```

Image: `03-shared-timing.jpg` — 1600×900 JPG.

Alt text: A dark Tranova card reads “Shared timing. Individual claims.” Four numbered blue recipient tracks share a grid with square controls at different positions. Supporting copy explains fully funded batches of up to 100 allocations. The footer labels Robinhood Chain Testnet.

## Profile assets

- `avatar.jpg` and `avatar.png`: 400×400; a blue orbital ring mark inside constellation circles on deep space, safe for a circular crop.
- `banner.jpg`: 1500×500; Tranova wordmark, “Make timing accountable.”, product line and an orbital ring mark. Essential text is clear of the lower-left profile overlap.
- `bio.txt`: profile text below X's 160-character limit.

At publication, keep the testnet label, use the matching image and alt text, and verify all links. No token launch, future airdrop, investment return, independent audit or official Robinhood partnership is implied.
