#!/usr/bin/env python3
"""Cosmos Orbit social artwork for the Tranova reskin.

Regenerates the X avatar, banner, three 1600x900 post cards and the 1200x630
OG image in the reskin art direction (void ground, orbital rings, one beam
accent). Same filenames and pixel dimensions as before, so the brand kit,
public downloads and validation stay consistent.
"""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[2]
IDENTITY = json.loads((ROOT / "branding" / "identity.json").read_text(encoding="utf-8"))
NAME = IDENTITY["name"]
SLUG = IDENTITY["slug"]

FONT = ROOT / "branding" / "sources" / "Manrope-Variable.ttf"
TWITTER = ROOT / "twitter"
BRANDING = ROOT / "branding"
PUBLIC_BRAND = ROOT / "website" / "public" / "brand"

VOID = (0, 0, 0)
DEEP = (5, 6, 11)
SURFACE = (18, 18, 30)
INK = (245, 244, 250)
DIM = (163, 161, 182)
FAINT = (139, 137, 160)
BEAM = (64, 179, 255)
AURA = (167, 139, 250)
EDGE = (38, 37, 54)


def font(size: int, weight: int = 500) -> ImageFont.FreeTypeFont:
    value = ImageFont.truetype(str(FONT), int(size))
    value.set_variation_by_axes([weight])
    return value


def text(draw: ImageDraw.ImageDraw, xy, value, size=28, fill=INK, weight=500, spacing=8) -> None:
    draw.multiline_text(xy, value, font=font(size, weight), fill=fill, spacing=spacing)


def kicker(draw: ImageDraw.ImageDraw, xy, value, fill=BEAM, size=18) -> None:
    draw.text(xy, " ".join(value.upper()), font=font(size, 700), fill=fill)


def mark(draw: ImageDraw.ImageDraw, cx: float, cy: float, radius: float, color=BEAM, bg=None) -> None:
    """Orbital ring with a gap, a solid core and one satellite dot."""
    width = max(2, int(radius * 0.14))
    box = [cx - radius, cy - radius, cx + radius, cy + radius]
    draw.arc(box, start=24, end=336, fill=color, width=width)
    core = radius * 0.34
    draw.ellipse([cx - core, cy - core, cx + core, cy + core], fill=color)
    sx, sy = cx + radius * 0.95, cy - radius * 0.12
    sr = max(2, radius * 0.11)
    draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=color)


def glow(im: Image.Image, cx: float, cy: float, radius: float, color, alpha: int = 70) -> None:
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 22
    for i in range(steps, 0, -1):
        r = radius * i / steps
        a = int(alpha * (1 - i / steps) ** 1.6)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (a,))
    im.alpha_composite(layer)


def rings(draw: ImageDraw.ImageDraw, cx: float, cy: float, base: float, color=BEAM, alpha=46) -> None:
    for scale, width in ((1.0, 1), (0.74, 1), (0.48, 1)):
        r = base * scale
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color + (alpha,), width=width)
    draw.ellipse([cx - base * 0.04, cy - base * 0.04, cx + base * 0.04, cy + base * 0.04], fill=color + (140,))


def canvas(size, ground=DEEP) -> Image.Image:
    im = Image.new("RGBA", size, ground + (255,))
    glow(im, size[0] * 0.82, size[1] * 0.12, size[1] * 0.9, BEAM, 74)
    glow(im, size[0] * 0.14, size[1] * 0.92, size[1] * 0.7, AURA, 46)
    return im


def save(im: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    im.convert("RGB").save(path, quality=95, subsampling=0, optimize=True)


def wordmark(draw: ImageDraw.ImageDraw, x: float, y: float, size: float = 30) -> None:
    mark(draw, x + size * 0.36, y + size * 0.5, size * 0.34)
    draw.text((x + size * 0.86, y + size * 0.06), NAME, font=font(size, 700), fill=INK)


def footer(draw: ImageDraw.ImageDraw, width: int, number: str, height: int = 900) -> None:
    y = height - 76
    draw.line((72, y, width - 72, y), fill=EDGE + (255,), width=2)
    kicker(draw, (72, y + 22), "Robinhood Chain Testnet", fill=FAINT, size=15)
    text(draw, (width - 300, y + 20), f"PRODUCT NOTES  /  {number}", 15, FAINT, 600)


def card_one() -> Image.Image:
    im = canvas((1600, 900))
    draw = ImageDraw.Draw(im, "RGBA")
    rings(draw, 1186, 432, 330, BEAM, 44)
    mark(draw, 1186, 432, 132, BEAM)
    wordmark(draw, 72, 54, 44)
    kicker(draw, (76, 214), "Timing with a clear owner")
    text(draw, (72, 258), "Make timing", 116, INK, 700, 4)
    text(draw, (72, 386), "accountable.", 116, INK, 700, 4)
    text(
        draw,
        (78, 566),
        "Vesting, locks, streams and\nvested distributions on one timeline.",
        32,
        DIM,
        500,
        14,
    )
    footer(draw, 1600, "01")
    return im


def card_two() -> Image.Image:
    im = canvas((1600, 900), SURFACE)
    draw = ImageDraw.Draw(im, "RGBA")
    draw.rectangle((1010, 0, 1600, 900), fill=DEEP + (255,))
    rings(draw, 1305, 430, 250, AURA, 40)
    wordmark(draw, 72, 54, 44)
    kicker(draw, (76, 190), "Set terms  /  fund  /  claim")
    text(draw, (72, 232), "Make the timing", 92, INK, 700, 4)
    text(draw, (72, 340), "visible.", 92, BEAM, 700, 4)
    text(
        draw,
        (78, 486),
        "An explicit cliff. A defined cadence.\nA release path recipients can inspect.",
        30,
        DIM,
        500,
        14,
    )
    # stepped release map
    ox, oy, w, h = 1044, 268, 468, 360
    for i in range(5):
        gy = oy + h * i / 4
        draw.line((ox, gy, ox + w, gy), fill=EDGE + (255,), width=2)
    points = [(ox, oy + h), (ox + 60, oy + h), (ox + 60, oy + h * 0.72), (ox + 150, oy + h * 0.72),
              (ox + 150, oy + h * 0.46), (ox + 300, oy + h * 0.46), (ox + 300, oy + h * 0.22),
              (ox + w, oy + h * 0.22)]
    draw.line(points, fill=BEAM + (255,), width=5)
    draw.ellipse([points[-1][0] - 9, points[-1][1] - 9, points[-1][0] + 9, points[-1][1] + 9], fill=AURA + (255,))
    text(draw, (ox, oy + h + 26), "START", 15, FAINT, 700)
    text(draw, (ox + w - 70, oy + h + 26), "RELEASE", 15, FAINT, 700)
    footer(draw, 1600, "02")
    return im


def card_three() -> Image.Image:
    im = canvas((1600, 900))
    draw = ImageDraw.Draw(im, "RGBA")
    rings(draw, 1295, 150, 185, BEAM, 36)
    wordmark(draw, 72, 54, 44)
    kicker(draw, (76, 196), "Vested distributions")
    text(draw, (72, 238), "Shared timing.", 92, INK, 700, 4)
    text(draw, (72, 346), "Individual claims.", 92, BEAM, 700, 4)
    text(
        draw,
        (78, 496),
        "Fund up to 100 allocations in one batch.\nEach recipient follows their own schedule.",
        30,
        DIM,
        500,
        14,
    )
    # recipient tracks
    bx, by, bw = 930, 250, 560
    for row in range(4):
        y = by + row * 118
        text(draw, (bx - 62, y + 2), f"0{row + 1}", 18, FAINT, 700)
        draw.line((bx, y + 16, bx + bw, y + 16), fill=EDGE + (255,), width=3)
        start = bx + row * 44
        end = start + 300 + row * 40
        draw.rounded_rectangle((start, y + 6, min(end, bx + bw), y + 26), radius=10, fill=BEAM + (255,))
        cx = start + 120 + row * 30
        draw.rectangle((cx - 12, y - 2, cx + 12, y + 34), fill=(AURA if row == 2 else INK) + (255,))
    text(draw, (bx, by + 4 * 118 + 4), "ILLUSTRATIVE RECIPIENT TRACKS", 14, FAINT, 700)
    footer(draw, 1600, "03")
    return im


def avatar() -> Image.Image:
    im = canvas((800, 800), DEEP)
    draw = ImageDraw.Draw(im, "RGBA")
    rings(draw, 400, 400, 300, BEAM, 60)
    mark(draw, 400, 400, 176, BEAM)
    return im.resize((400, 400), Image.Resampling.LANCZOS)


def banner() -> Image.Image:
    im = canvas((1500, 500))
    draw = ImageDraw.Draw(im, "RGBA")
    rings(draw, 1244, 250, 214, BEAM, 46)
    mark(draw, 1244, 250, 88, BEAM)
    wordmark(draw, 72, 54, 52)
    text(draw, (76, 168), "Make timing", 62, INK, 700, 2)
    text(draw, (76, 240), "accountable.", 62, INK, 700, 2)
    text(draw, (80, 350), "Vesting, locks, streams and vested distributions.", 22, DIM, 500)
    draw.line((76, 410, 1010, 410), fill=EDGE + (255,), width=2)
    kicker(draw, (78, 430), "Robinhood Chain Testnet", fill=FAINT, size=15)
    return im


def og_image() -> Image.Image:
    im = canvas((1200, 630))
    draw = ImageDraw.Draw(im, "RGBA")
    rings(draw, 962, 315, 176, BEAM, 44)
    mark(draw, 962, 315, 76, BEAM)
    wordmark(draw, 56, 44, 44)
    text(draw, (60, 156), "Make timing", 58, INK, 700, 2)
    text(draw, (60, 224), "accountable.", 58, INK, 700, 2)
    text(draw, (62, 322), "Vesting, locks, streams and vested distributions.", 20, DIM, 500)
    draw.line((60, 500, 800, 500), fill=EDGE + (255,), width=2)
    kicker(draw, (62, 522), "Robinhood Chain Testnet", fill=FAINT, size=14)
    return im


def main() -> int:
    save(card_one(), TWITTER / f"01-introducing-{SLUG}.jpg")
    save(card_two(), TWITTER / "02-release-map.jpg")
    save(card_three(), TWITTER / "03-shared-timing.jpg")
    av = avatar()
    av.save(TWITTER / "avatar.png")
    av.save(BRANDING / "avatar.png")
    save(av, TWITTER / "avatar.jpg")
    save(banner(), TWITTER / "banner.jpg")
    save(banner(), PUBLIC_BRAND / "banner.jpg")
    save(og_image(), PUBLIC_BRAND / "og-image.jpg")
    print(f"Cosmos Orbit artwork written for {NAME} ({SLUG}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
