# Tranova brand guidelines

**Tranova** is the product name. Use title case in prose and the wordmark; use `tranova` for identifiers. Pronounced **tra-NO-va**, the name combines tranche releases with nova renewal: each tranche arrives on its own visible date.

**Make timing accountable.**

The public domain is **www.tranova.site** (the apex `tranova.site` redirects to `www`) and the X account is **@TranovaSite**. Verify both whenever an asset is published: website links must use `https://www.tranova.site/` and social links must use `https://x.com/TranovaSite`. The earlier `.xyz` / `@tranova` check is historical preparation evidence in `docs/rebrand-2026/`, not the live identity.

## Product and voice

Tranova is a token release workspace for vesting, whole-date locks, finite streams and vested distributions. Describe observable behavior with direct language: set terms, review, fund, inspect and claim. Keep the **Robinhood Chain Testnet** stage visible. Do not imply network affiliation, independent audit, investment return, customer adoption or a future token entitlement.

The deployed test token has immutable historical metadata. The current interface labels the demonstration asset **Tranova Test USD** (`tUSD`); contract addresses and existing schedule rights remain unchanged.

## Visual system

| Color | Hex | Role |
| --- | --- | --- |
| Ink | `#0b0d14` | Deep structure, print text and mark interiors |
| Orbit ink | `#f5f4fa` | Interface text and reverse marks on the void ground |
| Beam | `#40b3ff` | Primary actions, release tracks and selected states |
| Accessible beam | `#0f6f9e` | Beam-family text on light paper |
| Aura | `#a78bfa` | Secondary markers and rare highlights |
| Dim | `#a3a1b6` | Supporting text on dark surfaces |
| Edge | `#262536` | Hairline rules and panel borders |
| Void | `#000000` | Workspace ground |
| Surface | `#12121e` | Panels and cards |
| Paper | `#ffffff` | Print and reverse surfaces |

The interface is a cosmos: a void ground, constellation gradients, hairline orbit rings and one beam accent. Typography pairs a geometric display face (Century Gothic / Futura with wide tracking) with self-hosted Manrope for body copy and mono labels for telemetry. Geometry is pill-based; a circular node marks a route or a release moment. Amber and aura colours are sparse accents, never body text on the void.

The mark is an orbital ring with a gap, a solid core and one satellite dot in a 48x48 view box. Keep its proportions and allow at least 8 view-box units of surrounding clear space. Use `logo.svg` on light surfaces, `logo-light.svg` on the void or ink. `logo-ivory.svg` is a compatibility filename for the same white mark. The wordmark uses outlined Manrope glyphs for portable rendering.

## Asset inventory and reproduction

- `logo*.svg`, `wordmark*.svg`, `favicon.svg`: scalable marks.
- `avatar.png` and `twitter/avatar.jpg`: 400×400 profile artwork, safe for circular cropping.
- `twitter/banner.jpg`: 1500×500, essential copy kept clear of the lower-left avatar overlap.
- `website/public/brand/og-image.jpg`: 1200×630 social preview.
- `twitter/01-introducing-tranova.jpg`, `02-release-map.jpg`, `03-shared-timing.jpg`: three 1600×900 launch cards in the Cosmos Orbit direction.
- `twitter/posts.md` and `bio.txt`: English drafts with alt text.

Run `python branding/sources/build_brand.py` for the vector identity, then `python branding/sources/build_social_orbit.py` for the Cosmos Orbit social and OG artwork (the second script intentionally overwrites the social cards from the first). Run `python branding/sources/build_business_plan.py`, then `render_business_plan.ps1`, to regenerate the print edition. Run `python branding/sources/package_materials.py` after validation to refresh public downloads and the brand kit. The dependencies are Pillow, fonttools, Markdown, PyMuPDF and a local Chromium browser for PDF printing. The supplied Manrope font is licensed under SIL OFL.

These are prepared materials. Asset creation does not publish a post, register an account, purchase a domain or establish legal exclusivity.
